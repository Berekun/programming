﻿namespace Rugby
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Partido partido = new Partido();
            partido.Ejecutar();
        }
    }
}